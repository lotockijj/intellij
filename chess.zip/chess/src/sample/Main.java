package sample;

/**
 * Created by Роман Лотоцький on 15.01.2017.
 */

import com.itextpdf.text.pdf.CMYKColor;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class Main extends Application {

    TextField textFieldReadFile, textFieldOutputDirectory, textForFile,
            documentWidth, documentHeight, titleFontSize, paragraphFontSize,
            boardInscriptionFontSize,tFFontFilePath,
            boardCellSize, boardLettersFrameWidth,
            partOfBoardAndButtonsLeftMargin, boardAndButtonsBottomMargin,
            marginAroundMostChessPieces, marginAroundPawnsAndRocksSides,
            textFieldCWhite, textFieldMWhite, textFieldYWhite, textFieldKWhite,
            textFieldCBlack, textFieldMBlack, textFieldYBlack, textFieldKBlack,
            textFieldCStart, textFieldMStart, textFieldYStart, textFieldKStart,
            textFieldCDist, textFieldMDist, textFieldYDist, textFieldKDist;

    CheckBox checkBox;
    PdfConfig pdfConfig;

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("Set data");

        pdfConfig = new PdfConfig();

        Button button = new Button("Choose file to read");

        textFieldReadFile = new TextField();
        textFieldReadFile.setOnMouseEntered(e -> textFieldReadFile.setPromptText("Choose file!!!"));
        textFieldReadFile.setOnMouseExited(e-> textFieldReadFile.setPromptText(""));
        Tooltip t = new Tooltip("I'm tool tip like hint for you :) ");
        t.setStyle("-fx-text-fill: black;-fx-background-color:white;-fx-padding:3;");
        textFieldReadFile.setTooltip(t);

        button.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Resource File");
            textFieldReadFile.setText(fileChooser.showOpenDialog(primaryStage).toString());
        });

        Button button2 = new Button("Output directory");
        textFieldOutputDirectory = new TextField();

        button2.setOnAction(e -> {
            DirectoryChooser dChooser = new DirectoryChooser();
            dChooser.setTitle("Choose directory to write");
            textFieldOutputDirectory.setText(dChooser.showDialog(primaryStage).toString());
        });

        Label nameOfFileToWrite = new Label("Name of file to write:");
        textForFile = new TextField();

        Button btnGenerate = new Button("Preference");
        btnGenerate.setOnAction( e -> generateNewWindow());

//        Button btnMultipleFile = new Button("Choose multiple files");
//        TextArea textArea = new TextArea();

//        btnMultipleFile.setOnAction(e -> {
//            FileChooser fileChooser = new FileChooser();
//            fileChooser.setTitle("Select PDF files");
//            fileChooser.setInitialDirectory(new File("D:\\робота\\Книги\\"));
//            fileChooser.getExtensionFilters().addAll(
//                    new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
//
//            List<File> selectedFiles = fileChooser.showOpenMultipleDialog(primaryStage);
//            String s = "";
//            for (File f: selectedFiles) {
//                s += f.toString() + "\n";
//            }
//            textArea.setText(s);
//        });

        VBox vBox = new VBox(10);
        vBox.setPadding(new Insets(10, 10, 10, 10));
        vBox.getChildren().addAll(button, textFieldReadFile, button2, textFieldOutputDirectory,
                nameOfFileToWrite, textForFile, btnGenerate);

        Button b = new Button("Generate");

        //image
        final ImageView imv = new ImageView();
        final Image image2 = new Image(
                Main.class.getResourceAsStream("pawn.jpg"));
        imv.setImage(image2);

        final VBox pictureRegion = new VBox();
        pictureRegion.setPadding(new Insets(10, 10, 10, 10));
        pictureRegion.getChildren().addAll(imv);

        BorderPane borderPane = new BorderPane();
        borderPane.setLeft(vBox);
        borderPane.setRight(pictureRegion);
        borderPane.setBottom(b);
        borderPane.setAlignment(b, Pos.BOTTOM_RIGHT);
        borderPane.setPadding(new Insets(20, 20, 20, 20));

        Scene scene = new Scene(borderPane, 490, 350);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void generateNewWindow() {

        Label labelGenMultipleFiles = new Label("Generate multiple files  ");
        labelGenMultipleFiles.setFont(Font.font("Default", FontWeight.BOLD, 15));

        checkBox = new CheckBox();
        checkBox.setSelected(true);
        HBox hBoxForGenMultFile = new HBox();
        hBoxForGenMultFile.getChildren().addAll(labelGenMultipleFiles, checkBox);

        Label documentSize = new Label("Document size:");
        documentSize.setFont(Font.font("Default", FontWeight.BOLD, 15));

        Label docWidt = new Label("Width: ");
        documentWidth = new TextField();
        documentWidth.setMaxWidth(50);
        documentWidth.setText(Integer.toString(pdfConfig.getDocumentWidth()));
        HBox hBoxForWidth = new HBox();
        hBoxForWidth.setSpacing(10);
        hBoxForWidth.setAlignment(Pos.CENTER_LEFT);
        hBoxForWidth.getChildren().addAll(docWidt, documentWidth);

        Label docHeight = new Label("Height:");
        documentHeight = new TextField();
        documentHeight.setMaxWidth(50);
        documentHeight.setText(Integer.toString(pdfConfig.getDocumentHeight()));
        HBox hBoxForHeight = new HBox();
        hBoxForHeight.setSpacing(10);
        hBoxForHeight.setAlignment(Pos.CENTER_LEFT);
        hBoxForHeight.getChildren().addAll(docHeight, documentHeight);

        VBox vBoxForSize = new VBox();
        vBoxForSize.setSpacing(10);
        vBoxForSize.setPadding(new Insets(10, 10, 10, 10));
        vBoxForSize.setBorder(new Border(new BorderStroke(Color.LIGHTGRAY,
                BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
        vBoxForSize.getChildren().addAll(documentSize, hBoxForWidth, hBoxForHeight);

        Label labelFontSize = new Label("Font size");
        labelFontSize.setFont(Font.font("Default", FontWeight.BOLD, 15));

        Label titleFontSizeLabel = new Label("Title font size:                     ");
        titleFontSize = new TextField();
        titleFontSize.setMaxWidth(50);
        titleFontSize.setText(Integer.toString(pdfConfig.getTitleFontSize()));
        HBox hBoxForTitleFontSize = new HBox();
        hBoxForTitleFontSize.setSpacing(10);
        hBoxForTitleFontSize.getChildren().addAll(titleFontSizeLabel, titleFontSize);

        Label paragraphFontSizeLabel = new Label("Paragraph font size:           ");
        paragraphFontSize = new TextField();
        paragraphFontSize.setMaxWidth(50);
        paragraphFontSize.setText(Integer.toString(pdfConfig.getParagraphFontSize()));
        HBox hBoxForParagraphFontSize = new HBox();
        hBoxForParagraphFontSize.setSpacing(10);
        hBoxForParagraphFontSize.getChildren().addAll(paragraphFontSizeLabel, paragraphFontSize);

        Label boardInscrLabel = new Label("Board inscription font size:");
        boardInscriptionFontSize = new TextField();
        boardInscriptionFontSize.setMaxWidth(50);
        boardInscriptionFontSize.setText(Integer.toString(pdfConfig.getBoardInscriptionFontSize()));
        HBox hBoxForBoardInscr = new HBox();
        hBoxForBoardInscr.setSpacing(10);
        hBoxForBoardInscr.getChildren().addAll(boardInscrLabel, boardInscriptionFontSize);

        VBox vBoxForFontSize = new VBox();
        vBoxForFontSize.setSpacing(10);
        vBoxForFontSize.setPadding(new Insets(10, 10, 10, 10));
        vBoxForFontSize.setBorder(new Border(new BorderStroke(Color.LIGHTGRAY,
                BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
        vBoxForFontSize.getChildren().addAll(labelFontSize, hBoxForTitleFontSize, hBoxForParagraphFontSize,
                hBoxForBoardInscr);

        Button fontFilePath = new Button("Font file path");

        tFFontFilePath = new TextField();

        Label labelColorSettings = new Label("Color settings");
        labelColorSettings.setFont(Font.font("Default", FontWeight.BOLD, 15));
        Label colorCells = new Label("Color of white cells:");

        initializeColors();

        HBox hBoxForColorWhite = cmykColorCreator(textFieldCWhite, textFieldMWhite, textFieldYWhite,
                textFieldKWhite, pdfConfig.getWhiteCellsColor());
        Label colorCellsBlack = new Label("Color of black cells");
        HBox hBoxForColorBlack = cmykColorCreator(textFieldCBlack, textFieldMBlack, textFieldYBlack,
                textFieldKBlack, pdfConfig.getBlackCellsColor());
        Label cellMove = new Label("Color of starting cell of every move");
        HBox hBoxColorStarting = cmykColorCreator(textFieldCStart, textFieldMStart, textFieldYStart,
                textFieldKStart, pdfConfig.getFromCellColor());
        Label cellDist = new Label("Color of distination cell of every move");
        HBox hBoxCellDist = cmykColorCreator(textFieldCDist, textFieldMDist, textFieldYDist,
                textFieldKDist, pdfConfig.getToCellColor());

        VBox vBoxForColors = new VBox();
        vBoxForColors.setSpacing(10);
        vBoxForColors.setPadding(new Insets(10, 10, 10, 10));
        vBoxForColors.setBorder(new Border(new BorderStroke(Color.LIGHTGRAY,
                BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
        vBoxForColors.getChildren().addAll(labelColorSettings, hBoxForColorWhite, hBoxForColorBlack,
                hBoxColorStarting, hBoxCellDist);

        Label boardSize = new Label("Board size");
        boardSize.setFont(Font.font("Default", FontWeight.BOLD, 15));

        Label labelBoardCellSize = new Label("Board cell size:                   ");
        boardCellSize = new TextField();
        boardCellSize.setMaxWidth(50);
        boardCellSize.setText(Integer.toString(pdfConfig.getBoardCellSize()));
        HBox hBoxCellSize = new HBox();
        hBoxCellSize.setSpacing(10);
        hBoxCellSize.setAlignment(Pos.CENTER_LEFT);
        hBoxCellSize.getChildren().addAll(labelBoardCellSize, boardCellSize);

        Label labelBoardFrame = new Label("Board letters frame width: ");
        boardLettersFrameWidth = new TextField();
        boardLettersFrameWidth.setMaxWidth(50);
        boardLettersFrameWidth.setText(Integer.toString(pdfConfig.getBoardLettersFrameWidth()));
        HBox hBoxLettersFrame = new HBox();
        hBoxLettersFrame.setSpacing(10);
        hBoxLettersFrame.setAlignment(Pos.CENTER_LEFT);
        hBoxLettersFrame.getChildren().addAll(labelBoardFrame, boardLettersFrameWidth);

        VBox vBoxBoardSize = new VBox();
        vBoxBoardSize.setSpacing(10);
        vBoxBoardSize.setPadding(new Insets(10, 10, 10, 10));
        vBoxBoardSize.setBorder(new Border(new BorderStroke(Color.LIGHTGRAY,
                BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
        vBoxBoardSize.getChildren().addAll(boardSize, hBoxCellSize, hBoxLettersFrame);

        Label labelMargins = new Label("Margins to place board"); // to place chess piece...
        labelMargins.setFont(Font.font("Default", FontWeight.BOLD, 15));
        Label labelMarg = new Label("Part of left margin:                ");
        partOfBoardAndButtonsLeftMargin = new TextField();
        partOfBoardAndButtonsLeftMargin.setMaxWidth(50);
        partOfBoardAndButtonsLeftMargin.setText(Integer.
                toString(pdfConfig.getPartOfBoardAndButtonsLeftMargin()));
        HBox hBoxMarg= new HBox();
        hBoxMarg.setSpacing(10);
        hBoxMarg.setAlignment(Pos.CENTER_LEFT);
        hBoxMarg.getChildren().addAll(labelMarg, partOfBoardAndButtonsLeftMargin);

        Label labelMarg2 = new Label("Bottom margin:                     ");
        boardAndButtonsBottomMargin = new TextField();
        boardAndButtonsBottomMargin.setMaxWidth(50);
        boardAndButtonsBottomMargin.setText(Integer.
                toString(pdfConfig.getBoardAndButtonsBottomMargin()));
        HBox hBoxMarg2= new HBox();
        hBoxMarg2.setSpacing(10);
        hBoxMarg2.setAlignment(Pos.CENTER_LEFT);
        hBoxMarg2.getChildren().addAll(labelMarg2, boardAndButtonsBottomMargin);

        VBox vBoxMargin = new VBox();
        vBoxMargin.setSpacing(10);
        vBoxMargin.setPadding(new Insets(10, 10, 10, 10));
        vBoxMargin.setBorder(new Border(new BorderStroke(Color.LIGHTGRAY,
                BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
        vBoxMargin.getChildren().addAll(labelMargins, hBoxMarg,  hBoxMarg2);

        Label labelMargins2 = new Label("Margins to place chess pieces to cells");
        labelMargins2.setFont(Font.font("Default", FontWeight.BOLD, 15));
        Label labelMarginAround = new Label("Margin around most chess:");
        marginAroundMostChessPieces = new TextField();
        marginAroundMostChessPieces.setMaxWidth(50);
        marginAroundMostChessPieces.setText(Integer.
                toString(pdfConfig.getMarginAroundMostChessPieces()));
        HBox hBoxMA = new HBox();
        hBoxMA.setSpacing(10);
        hBoxMA.setAlignment(Pos.CENTER_LEFT);
        hBoxMA.getChildren().addAll(labelMarginAround, marginAroundMostChessPieces);

        Label labelAroundPawns = new Label("Margin around pawns:       ");
        marginAroundPawnsAndRocksSides = new TextField();
        marginAroundPawnsAndRocksSides.setMaxWidth(50);
        marginAroundPawnsAndRocksSides.setText(Integer
                .toString(pdfConfig.getMarginAroundPawnsAndRocksSides()));
        HBox hBoxAP = new HBox();
        hBoxAP.setSpacing(10);
        hBoxAP.setAlignment(Pos.CENTER_LEFT);
        hBoxAP.getChildren().addAll(labelAroundPawns, marginAroundPawnsAndRocksSides);

        VBox vBoxMargin2 = new VBox();
        vBoxMargin2.setSpacing(10);
        vBoxMargin2.setPadding(new Insets(10, 10, 10, 10));
        vBoxMargin2.setBorder(new Border(new BorderStroke(Color.LIGHTGRAY,
                BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
        vBoxMargin2.getChildren().addAll(labelMargins2, hBoxMA, hBoxAP);

        VBox vBox = new VBox();
        vBox.setPadding(new Insets(10, 10, 10, 10));
        vBox.setSpacing(5);
        vBox.getChildren().addAll(hBoxForGenMultFile, vBoxForSize, vBoxForFontSize,
                fontFilePath, tFFontFilePath, vBoxForColors);

        HBox hBox = new HBox();
        hBox.setSpacing(10);
        hBox.setAlignment(Pos.BASELINE_CENTER);
        hBox.setPadding(new Insets(10, 10, 10, 10));
        Button sumbit = new Button("Submit");

        Button defaultData = new Button("Default data");
        defaultData.setOnAction(e -> createPdfConfigWithDefaultData());
        hBox.getChildren().addAll(defaultData, sumbit);

        HBox hBoxSpace = new HBox();
        hBoxSpace.setMinHeight(70);
        VBox vBox2 = new VBox();
        vBox2.setPadding(new Insets(10, 10, 10, 10));
        vBox2.setSpacing(5);
        vBox2.getChildren().addAll(vBoxBoardSize, vBoxMargin, vBoxMargin2, hBoxSpace, hBox);

        BorderPane borderPaneIn = new BorderPane();
        borderPaneIn.setLeft(vBox);
        borderPaneIn.setRight(vBox2);

        Scene scene = new Scene(borderPaneIn, 650, 620);
        Stage stage = new Stage();
        stage.setTitle("Generate new files");
        stage.setScene(scene);
        //Fill stage with content
        stage.show();
        sumbit.setOnAction(e -> {
            createPdfConfig();
            stage.hide();
        });
        fontFilePath.setOnAction(e ->{
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Resource File");
            tFFontFilePath.setText(fileChooser.showOpenDialog(stage).toString());
        });
    }

    private void initializeColors() {
        textFieldCWhite = new TextField(Float.toString(pdfConfig.getWhiteCellsColor().getCyan()));
        textFieldMWhite = new TextField(Float.toString(pdfConfig.getWhiteCellsColor().getMagenta()));
        textFieldYWhite = new TextField(Float.toString(pdfConfig.getWhiteCellsColor().getYellow()));
        textFieldKWhite = new TextField(Float.toString(pdfConfig.getWhiteCellsColor().getBlack()));

        textFieldCBlack = new TextField(Float.toString(pdfConfig.getBlackCellsColor().getCyan()));
        textFieldMBlack = new TextField(Float.toString(pdfConfig.getBlackCellsColor().getMagenta()));
        textFieldYBlack = new TextField(Float.toString(pdfConfig.getBlackCellsColor().getYellow()));
        textFieldKBlack = new TextField(Float.toString(pdfConfig.getBlackCellsColor().getBlack()));

        textFieldCStart = new TextField(Float.toString(pdfConfig.getFromCellColor().getCyan()));
        textFieldMStart = new TextField(Float.toString(pdfConfig.getFromCellColor().getMagenta()));
        textFieldYStart = new TextField(Float.toString(pdfConfig.getFromCellColor().getYellow()));
        textFieldKStart = new TextField(Float.toString(pdfConfig.getFromCellColor().getBlack()));

        textFieldCDist = new TextField(Float.toString(pdfConfig.getToCellColor().getCyan()));
        textFieldMDist = new TextField(Float.toString(pdfConfig.getToCellColor().getMagenta()));
        textFieldYDist = new TextField(Float.toString(pdfConfig.getToCellColor().getYellow()));
        textFieldKDist = new TextField(Float.toString(pdfConfig.getFromCellColor().getBlack()));

        TextField[] arrayTextField  = {textFieldCWhite, textFieldMWhite, textFieldYWhite, textFieldKWhite,
                textFieldCBlack, textFieldMBlack, textFieldYBlack, textFieldKBlack,
                textFieldCStart, textFieldMStart, textFieldYStart, textFieldKStart,
                textFieldCDist, textFieldMDist, textFieldYDist, textFieldKDist};
        for (TextField e: arrayTextField) {
            e.setMaxWidth(50);
        }
    }

    private HBox cmykColorCreator(TextField textFieldCWhite, TextField textFieldM,
                                  TextField textFieldY, TextField textFieldK,
                                  CMYKColor whiteCellsColor) {
        Label c = new Label(" c  ");
        Label m = new Label(" m  ");
        Label y = new Label(" y  ");
        Label k = new Label(" k  ");

        HBox hBoxForColor = new HBox();
        hBoxForColor.setAlignment(Pos.CENTER_LEFT);
        hBoxForColor.getChildren().addAll(c, textFieldCWhite, m, textFieldM, y, textFieldY, k, textFieldK);
        return hBoxForColor;
    }

    private void createPdfConfigWithDefaultData() {
        System.out.println(pdfConfig);
    }

    private void createPdfConfig() {
        pdfConfig = new PdfConfig();
        validateDocument();

        pdfConfig.setInputFilePath(textFieldReadFile.getText());
        pdfConfig.setResultingDirectoryPath(textFieldOutputDirectory.getText());
        pdfConfig.setResultingFileName(textForFile.getText());
        pdfConfig.setDocumentWidth(Integer.parseInt(documentWidth.getText()));
        pdfConfig.setDocumentHeight(Integer.parseInt(documentHeight.getText()));
        pdfConfig.setGenerateMultipleFiles(checkBox.isSelected());
        pdfConfig.setTitleFontSize(Integer.parseInt(titleFontSize.getText()));
        pdfConfig.setParagraphFontSize(Integer.parseInt(paragraphFontSize.getText()));
        pdfConfig.setBoardInscriptionFontSize(Integer.parseInt(boardInscriptionFontSize.getText()));
        pdfConfig.setFontFilePath(tFFontFilePath.getText());

        System.out.println(pdfConfig);
    }

    private void validateDocument(){
        validateIntergerData(documentWidth, "Width is not number", "Choose number");
        validateIntergerData(documentHeight, "Height is not number", "Choose number for height");
        validateIntergerData(titleFontSize, "Title font size is not number", "Choose number for title font size");
        validateIntergerData(boardInscriptionFontSize, "Board inscription font size is not number", "Choose number for board inscrition");
        validateAllFloatData(textFieldCWhite, textFieldMWhite, textFieldYWhite, textFieldKWhite,
                textFieldCBlack, textFieldMBlack, textFieldYBlack, textFieldKBlack,
                textFieldCStart, textFieldMStart, textFieldYStart, textFieldKStart,
                textFieldCDist, textFieldMDist, textFieldYDist, textFieldKDist);
        validateIntergerData(boardCellSize, "Board cell size is not number", "Choose number for board size.");
        validateIntergerData(boardLettersFrameWidth, "Board letters frame width is not number", "Choose number ");
        validateIntergerData(partOfBoardAndButtonsLeftMargin, "Left margin is not number" , "Choose number");
        validateIntergerData(boardAndButtonsBottomMargin, "Bottom margin is not number", "Choose number");
        validateIntergerData(marginAroundMostChessPieces, "Margin around most chess pieces is not number", "Choose number");
        validateIntergerData(marginAroundPawnsAndRocksSides, "Margin around pawns is not number", "Choose nubmer");
    }

    private void validateAllFloatData(TextField... colorSettings) {
        for (int i = 0; i < colorSettings.length; i++) {
                validateSingleFloatData(colorSettings[i].getText(),
                        "Bad number for color", "Choose right number.");
        }
    }

    private int validateIntergerData(TextField documentData, String s1, String s2){
        int number = 0;
        try{
            number = Integer.valueOf(documentData.getText());
        } catch (Exception e){
            FxDialogs.showException(s1, s2,  e);
            System.out.println(e);
        }
        return number;
    }

    private float validateSingleFloatData(String documentData, String s1, String s2){
        float number = 0.0f;
        try{
            number = Float.valueOf(documentData);
        } catch (Exception e){
            FxDialogs.showException(s1, s2,  e);
            System.out.println(e);
        }
        return number;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
